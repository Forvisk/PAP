lista = [x | x <- [1 .. 10], mod x 2 == 0]
