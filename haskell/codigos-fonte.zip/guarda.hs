guarda x | ( x == 0 ) = 0
         | ( x == 1 ) = 1
         | otherwise = 10
