soma 0 = 0
soma 1 = 1
soma n = soma (n - 1) + n
