list_size [] = 0
list_size (listHead:listTail) = 1 + list_size listTail
